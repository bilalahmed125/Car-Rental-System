package com.bilal.models.users;

public class Admin {
    
}
